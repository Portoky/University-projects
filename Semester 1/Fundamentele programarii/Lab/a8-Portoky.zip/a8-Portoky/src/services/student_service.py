from src.domain.student import Student

class StudentService:
    def __init__(self, student_repository):
        self.__student_repository = student_repository

    def add_student(self, student_id: str, student_name: str):
        student = Student(student_id, student_name)
        self.__student_repository.add(student)

    def remove_student(self, student_id):
        student = self.__student_repository.find_by_id(student_id)
        self.__student_repository.remove(student)

    def list_students(self):
        return self.__student_repository.find_all()

    def update_student(self, student_id, student_name):
        student = Student(student_id, student_name)
        self.__student_repository.update(student)

    def find_student_by_id(self, student_id):
        return self.__student_repository.find_by_id(student_id)

    def find_student_by_name(self, student_name):
        '''Returns a list(!) of all the instances where the name partially matches'''
        return self.__student_repository.find_by_name(student_name)
