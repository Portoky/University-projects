from src.domain.discipline import Discipline


class DisciplineService:
    def __init__(self, discipline_repository):
        self.__discipline_repository = discipline_repository

    def add_discipline(self, discipline_id: str, discipline_name: str):
        discipline = Discipline(discipline_id, discipline_name)
        self.__discipline_repository.add(discipline)

    def remove_discipline(self, discipline_id):
        discipline = self.__discipline_repository.find_by_id(discipline_id)
        self.__discipline_repository.remove(discipline)

    def list_disciplines(self):
        return self.__discipline_repository.find_all()

    def update_discipline(self, discipline_id, discipline_name):
        discipline = Discipline(discipline_id, discipline_name)
        self.__discipline_repository.update(discipline)

    def find_discipline_by_id(self, discipline_id):
        return self.__discipline_repository.find_by_id(discipline_id)

    def find_discipline_by_name(self, discipline_name):
        '''Returns a list(!) of all the instances where the name partially matches'''
        return self.__discipline_repository.find_by_name(discipline_name)
