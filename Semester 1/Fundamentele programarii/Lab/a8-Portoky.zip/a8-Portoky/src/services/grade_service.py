from src.domain import dto
from src.domain.grade import Grade
from src.domain.dto import *

class GradeService:
    def __init__(self, grade_repository, student_repository, discipline_repository):
        self.__grade_repository = grade_repository
        self.__student_repository = student_repository
        self.__discipline_repository = discipline_repository

    def add_grade(self, grade_id, discipline_id, student_id, grade_value):
        grade = Grade(grade_id, discipline_id, student_id, grade_value)
        self.__grade_repository.add(grade)

    def list_grades(self):
        return self.__grade_repository.find_all()

    #TODO statistics, dtos

    def get_failing_students(self):
        statistic_dtos = self.create_statistics_dtos()
        failing_students = []
        for student in self.__student_repository.find_all():
            for dto in statistic_dtos:
                if student.id == dto.student_id and dto.average_grade_value < 5 and dto.average_grade_value != 0:
                    failing_students.append(student)
                    break
        return failing_students

    def get_best_students(self):
        best_students = []
        overall_dtos = self.create_overall_student_dtos()
        overall_dtos.sort(key=lambda dto: dto.medium, reverse=True)
        for dto in overall_dtos:
            best_students.append(self.__student_repository.find_by_id(dto.student_id))
        return best_students

    def get_best_disciplines(self):
        '''Returns a list of disciplines sorted by average grade received by all students.'''
        best_disciplines = []
        overall_dtos = self.create_overall_discipline_dtos()
        overall_dtos.sort(key=lambda dto: dto.medium, reverse=True)
        for dto in overall_dtos:
            best_disciplines.append(self.__discipline_repository.find_by_id(dto.discipline_id))
        return best_disciplines

    def create_overall_discipline_dtos(self):
        overall_discipline_dtos = []
        statistic_dtos =self.create_statistics_dtos()
        for discipline in self.__discipline_repository.find_all():
            sum_of_average_grade = 0
            number_of_students = 0
            for dto in statistic_dtos:
                if dto.discipline_id == discipline.id:
                    sum_of_average_grade += dto.average_grade_value
                    number_of_students += 1
            if number_of_students > 0:
                medium = sum_of_average_grade / number_of_students
                overall_discipline_dto = OverallDisciplineDto(discipline.id, medium)
                overall_discipline_dtos.append(overall_discipline_dto)

        return overall_discipline_dtos
    def create_overall_student_dtos(self):
        overall_student_dtos = []
        statistic_dtos = self.create_statistics_dtos()
        for student in self.__student_repository.find_all():
            sum_of_average_grade = 0
            number_of_disciplines = 0
            for dto in statistic_dtos:
                if dto.student_id == student.id:
                    sum_of_average_grade += dto.average_grade_value
                    number_of_disciplines += 1
            if number_of_disciplines > 0:
                medium = sum_of_average_grade / number_of_disciplines
                overall_student_dto = OverallStudentDto(student.id, medium)
            else:
                overall_student_dto = OverallStudentDto(student.id, 0)
            overall_student_dtos.append(overall_student_dto)

        return overall_student_dtos

    def create_statistics_dtos(self):
        statistic_dtos = []
        for student in self.__student_repository.find_all():
            for discipline in self.__discipline_repository.find_all():
                sum_of_grades = 0
                number_of_grades = 0
                for grade in self.__grade_repository.find_all():
                    if grade.student_id == student.id and grade.discipline_id == discipline.id:
                            sum_of_grades += grade.grade_value
                            number_of_grades += 1

                if number_of_grades > 0:
                    average_grade = sum_of_grades / number_of_grades
                    statistic_dto = StatisticsDto(student.id, discipline.id, average_grade)
                else:
                    statistic_dto = StatisticsDto(student.id, discipline.id, 0)
                statistic_dtos.append(statistic_dto)

        return statistic_dtos

