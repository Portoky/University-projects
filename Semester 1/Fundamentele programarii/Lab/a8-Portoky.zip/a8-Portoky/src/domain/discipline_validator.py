
from src.domain.exceptions import ValidatorException

class DisciplineValidator:
    def validate(self, discipline):
        if discipline.name == "":
            raise ValidatorException(["Invalid name for discipline"])

