from dataclasses import dataclass


@dataclass
class Discipline():
    __discipline_id: str
    __discipline_name: str

    @property
    def name(self):
        return self.__discipline_name

    @name.setter
    def name(self, new_name):
        self.__discipline_name = new_name

    @property
    def id(self):
        return self.__discipline_id

    @id.setter
    def id(self, new_id):
        self.__discipline_id = new_id

    def __str__(self):
        return str(self.id) + ": " + str(self.name)
