from dataclasses import dataclass


@dataclass
class Student:
    __student_id: str
    __student_name: str

    @property
    def name(self):
        return self.__student_name

    @property
    def id(self):
        return self.__student_id

    @name.setter
    def name(self, new_name):
        self.__student_name = new_name

    @id.setter
    def id(self, new_id):
        self.__student_id = new_id

    def __str__(self):
        return str(self.id) + ": " + str(self.name)

# if __name__ == "__main__":
#     stu = Student(1, "")
#     validator = StudentValidator()
#     try:
#         validator.validate(stu)
#     except ValidatorException as Ve:
#         print(Ve)