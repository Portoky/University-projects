
from src.domain.exceptions import ValidatorException

class StudentValidator:
    def validate(self, student):
        if student.name == "":
            raise ValidatorException(["Invalid name for student"])

