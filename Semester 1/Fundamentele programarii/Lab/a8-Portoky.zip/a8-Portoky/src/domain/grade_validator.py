
from src.domain.exceptions import ValidatorException

class GradeValidator:
    def validate(self, grade):
        if grade.grade_value > 10 or grade.grade_value < 0:
            raise ValidatorException(["Invalid grading!"])
