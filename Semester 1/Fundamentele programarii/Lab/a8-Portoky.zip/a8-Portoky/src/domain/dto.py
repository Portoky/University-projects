from dataclasses import dataclass


@dataclass
class StatisticsDto:
    student_id: str
    discipline_id: str
    average_grade_value: float


@dataclass
class OverallStudentDto:
    student_id: str
    medium: float

@dataclass
class OverallDisciplineDto:
    discipline_id: str
    medium: float
