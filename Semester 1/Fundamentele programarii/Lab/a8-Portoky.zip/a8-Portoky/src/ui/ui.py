from src.domain.exceptions import ValidatorException
from src.services.grade_service import GradeService
from src.services.student_service import StudentService
from src.services.discipline_service import DisciplineService
from src.repository.repository_exception import RepositoryException

class Console:
    def __init__(self, grade_service, student_service, discipline_service):
        self.__grade_service = grade_service
        self.__student_service = student_service
        self.__discipline_service = discipline_service
        self.commands = {"s1": self.add_student, "s2": self.remove_student, "s3": self.update_student, "s4": self.list_students, "s5": self.search_student_by_id,
                         "d1": self.add_discipline, "d2": self.remove_discipline, "d3": self.update_discipline, "d4": self.list_disciplines, "d5": self.search_discipline_by_id,
                         "g1": self.add_grade, "g2": self.list_failing_students, "g3": self.list_students_sorted_by_average, "g4": self.list_disciplines_sorted_by_average}
        self.generate_items()

    def generate_items(self):
        self.__student_service.add_student("1", "Emese")
        self.__student_service.add_student("2", "Marci")
        self.__student_service.add_student("3", "Boti")
        self.__student_service.add_student("4", "Robi")
        self.__discipline_service.add_discipline("1", "Maths")
        self.__discipline_service.add_discipline("2", "Informatics")
        self.__discipline_service.add_discipline("3", "Biology")
        self.__discipline_service.add_discipline("4", "Physics")
        self.__grade_service.add_grade("1", "1", "1", 10)
        self.__grade_service.add_grade("2", "1", "2", 8)
        self.__grade_service.add_grade("3", "1", "3", 5)
        self.__grade_service.add_grade("4", "1", "4", 2)
        self.__grade_service.add_grade("5", "2", "1", 10)
        self.__grade_service.add_grade("6", "2", "3", 9)
        self.__grade_service.add_grade("7", "3", "4", 10)
        self.__grade_service.add_grade("8", "3", "2", 10)
        self.__grade_service.add_grade("9", "4", "4", 7)
        self.__grade_service.add_grade("10", "4", "3", 6)
        self.__grade_service.add_grade("11", "2", "4", 4)
        self.__grade_service.add_grade("12", "3", "1", 3)

    def print_options(self):
        print("x: Exit the application")
        print("s1: Add student")
        print("s2: Remove student")
        print("s3: Update student")
        print("s4: List students")
        print("d1: Add discipline")
        print("d2: Remove discipline")
        print("d3: Update discipline")
        print("d4: List disciplines")
        print("g1: Add grade")
        print("g2: List failing students")
        print("g3: List students sorted by their grades' average")
        print("g4: List disciplines sorted by their averaged grades")

    def run_console(self):
        self.print_options()
        while True:
            command = input(">").lower()
            if command == "x":
                print("Thanks for using the application! :)")
                break
            try:
                self.commands[command]()
            except KeyError:
                print("Option not implemented yet!")
            except RepositoryException as re:
                print("Repository error: " + str(re))
            except ValidatorException as ve:
                print("Validation error: " + str(ve))


    def add_student(self):
        student_id = input("Student ID: ")
        student_name = input("Student Name: ")
        self.__student_service.add_student(student_id, student_name)


    def remove_student(self):
        student_id = input("Student ID: ")
        self.__student_service.remove_student(student_id)

    def update_student(self):
        student_id = input("Student ID: ")
        student_name = input("Student Name: ")
        self.__student_service.update_student(student_id, student_name)

    def list_students(self):
        for student in self.__student_service.list_students():
            print(student)

    def search_student_by_id(self):
        pass

    def add_discipline(self):
        discipline_id = input("Discipline ID: ")
        discipline_name = input("Discipline Name: ")
        self.__discipline_service.add_discipline(discipline_id, discipline_name)


    def remove_discipline(self):
        discipline_id = input("Discipline ID: ")
        self.__discipline_service.remove_discipline(discipline_id)


    def update_discipline(self):
        discipline_id = input("Discipline ID: ")
        discipline_name = input("Discipline Name: ")
        self.__discipline_service.update_discipline(discipline_id, discipline_name)

    def list_disciplines(self):
        for discipline in self.__discipline_service.list_disciplines():
            print(discipline)

    def search_discipline_by_id(self):
        pass
    def add_grade(self):
        grade_id = input("Grade ID: ")
        discipline_id = input("Discipline ID: ")
        student_id = input("Student ID: ")
        grade_value = int(input("Grade value: "))
        self.__grade_service.add_grade(grade_id, discipline_id, student_id, grade_value)

    def list_failing_students(self):
        failing_students = self.__grade_service.get_failing_students()
        for student in failing_students:
            print(student)

    def list_students_sorted_by_average(self):
        best_students = self.__grade_service.get_best_students()
        for student in best_students:
            print(student)

    def list_disciplines_sorted_by_average(self):
        best_disciplines = self.__grade_service.get_best_disciplines()
        for discipline in best_disciplines:
            print(discipline)

