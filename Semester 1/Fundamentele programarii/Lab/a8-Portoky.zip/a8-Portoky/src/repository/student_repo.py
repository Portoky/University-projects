from src.domain.student_validator import StudentValidator
from src.repository.grade_repo import GradeRepo
from src.repository.repository_exception import RepositoryException


class StudentRepo:
    def __init__(self, validator: StudentValidator, grade_repo: GradeRepo):
        self._students = {}
        self.__validator = validator
        self.__grade_repo = grade_repo  # same layer the repos can know about eachother

    """Crud operations"""

    def find_all(self):
        return list(self._students.values())

    def find_by_id(self, student_id: str):
        if student_id in self._students.keys():
            return self._students[student_id]
        return None

    def find_by_name(self, name: str):
        """
        Returns a list of students with all partially matching names
        :param name:
        :return:
        """
        result = []
        for student in self.find_all():
            if name in student.name:
                result.append(student)
        if len(result) == 0:
            raise RepositoryException("Name not in repo!")
        else:
            return result

    def add(self, student):
        if self.find_by_id(student.id):
            raise RepositoryException("Duplicate Student ID")
        self.__validator.validate(student)
        self._students[student.id] = student

    def remove(self, student):
        if self.find_by_id(student.id) is not None:
            # removing all the instances with the student from grades
            for grade in self.__grade_repo.find_all():
                if grade.student_id == student.id:
                    self.__grade_repo.remove_by_id(grade.grade_id)
            del self._students[student.id]
        else:
            raise RepositoryException("Student ID was not found")

    def update(self, student):
        self.__validator.validate(student)
        if self.find_by_id(student.id) is None:
            raise RepositoryException("Student ID does not exist")
        self._students[student.id] = student

    def __len__(self):
        return len(self._students)
