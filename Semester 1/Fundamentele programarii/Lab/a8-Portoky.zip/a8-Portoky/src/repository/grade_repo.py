from src.domain.grade_validator import GradeValidator
from src.domain.grade import Grade
from src.repository.repository_exception import RepositoryException


class GradeRepo:
    def __init__(self, validator: GradeValidator):
        self._grades = {}
        self.__validator = validator

    @property
    def grades(self):
        return self._grades

    def find_all(self):
        return list(self._grades.values())

    def find_by_id(self, grade_id: str):
        if grade_id not in self.grades:
            return None
        return self.grades[grade_id]

    def add(self, grade: Grade):
        if self.find_by_id(grade.grade_id) is not None:
            raise RepositoryException("Duplicate Grade ID")
        self.__validator.validate(grade)
        self.grades[grade.grade_id] = grade

    def remove_by_id(self, grade_id: str):
        if self.find_by_id(grade_id) is None:
            raise RepositoryException("Grade ID was not found")
        del self._grades[grade_id]

    def update(self, new_grade: Grade):
        if self.find_by_id(new_grade.grade_id) is None:
            raise RepositoryException("Grade not in repository")
        self.__validator.validate(new_grade)
        self.grades[new_grade.grade_id] = new_grade



    # def find_all_students(self, student):
    #     return self
    #
    # def remove_by_student_id(self, student_id):

