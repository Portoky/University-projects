from src.domain.discipline_validator import DisciplineValidator
from src.domain.discipline import Discipline
from src.repository.grade_repo import GradeRepo
from src.repository.repository_exception import RepositoryException


class DisciplineRepo:
    def __init__(self, validator: DisciplineValidator, grade_repo: GradeRepo):
        self._disciplines = {}
        self.__validator = validator
        self.__grade_repo = grade_repo

    """Crud operations"""

    def find_all(self):
        return list(self._disciplines.values())

    def find_by_id(self, discipline_id: str):
        if discipline_id in self._disciplines.keys():
            return self._disciplines[discipline_id]
        return None

    def find_by_name(self, name: str):
        """
        Returns a list of discipline with all partially matching names
        :param name:
        :return:
        """
        result = []
        for discipline in self.find_all():
            if name in discipline.name:
                result.append(discipline)
        if len(result) == 0:
            raise RepositoryException("Name not in repo!")
        else:
            return result

    def add(self, discipline: Discipline):
        if self.find_by_id(discipline.id) is not None:
            raise RepositoryException("Discipline already in repo")
        self.__validator.validate(discipline)
        self._disciplines[discipline.id] = discipline

    def remove(self, discipline: Discipline):
        if self.find_by_id(discipline.id) is not None:
            # removing all the instances with the discipline from grades
            for grade in self.__grade_repo.find_all():
                if grade.discipline_id == discipline.id:
                    self.__grade_repo.remove_by_id(grade.grade_id)
            del self._disciplines[discipline.id]

        else:
            raise RepositoryException("Discipline ID was not found")

    def update(self, discipline):
        self.__validator.validate(discipline)
        if self.find_by_id(discipline.id) is None:
            raise RepositoryException("Student ID does not exist")
        self._disciplines[discipline.id] = discipline
