import src.ui.ui
from src.domain.discipline_validator import DisciplineValidator
from src.domain.grade import Grade
from src.domain.grade_validator import GradeValidator
from src.repository.discipline_repo import DisciplineRepo
from src.repository.grade_repo import GradeRepo
from src.repository.student_repo import StudentRepo
from src.domain.student_validator import StudentValidator
from src.domain.student import Student
from src.domain.discipline import Discipline
from src.services.discipline_service import DisciplineService
from src.services.grade_service import GradeService
from src.services.student_service import StudentService
from src.ui.ui import Console

if __name__ == "__main__":
    grade_repo = GradeRepo(GradeValidator())
    student_repo = StudentRepo(StudentValidator(), grade_repo)
    discipline_repo = DisciplineRepo(DisciplineValidator(), grade_repo)
    grade_service = GradeService(grade_repo, student_repo, discipline_repo)
    student_service = StudentService(student_repo)
    discipline_service = DisciplineService(discipline_repo)
    console = Console(grade_service, student_service, discipline_service)
    console.run_console()
