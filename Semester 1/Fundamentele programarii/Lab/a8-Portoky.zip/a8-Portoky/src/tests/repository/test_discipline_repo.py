import unittest

from src.repository.repository_exception import RepositoryException
from src.domain.discipline import Discipline
from src.domain.discipline_validator import DisciplineValidator
from src.repository.discipline_repo import DisciplineRepo
from src.repository.grade_repo import GradeRepo
from src.domain.grade_validator import GradeValidator



class TestDisciplineRepo(unittest.TestCase):
    def setUp(self) -> None:
        self.validator = DisciplineValidator()
        self.discipline_repo = DisciplineRepo(self.validator, GradeRepo(GradeValidator()))
        self.discipline = Discipline("1", "Lol")

    def test_addition(self):
        self.discipline_repo.add(self.discipline)
        self.assertEqual(self.discipline_repo.find_by_id("1"), self.discipline)

    def test_remove(self):
        self.discipline_repo.add(self.discipline)
        self.discipline_repo.remove(self.discipline)
        self.assertEqual(self.discipline_repo.find_by_id("1"), None)

    def test_get_all(self):
        self.discipline_repo.add(self.discipline)
        self.assertEqual(self.discipline_repo.find_all(), [self.discipline])

    def test_update(self):
        self.discipline_repo.add(self.discipline)
        new_discipline = Discipline("1", "Maths")
        self.discipline_repo.update(new_discipline)
        self.assertEqual(self.discipline_repo.find_by_id("1"), new_discipline)