import unittest

from src.repository.repository_exception import RepositoryException
from src.domain.student import Student
from src.domain.student_validator import StudentValidator
from src.repository.student_repo import StudentRepo
from src.repository.grade_repo import GradeRepo
from src.domain.grade_validator import GradeValidator


class TestStudentRepo(unittest.TestCase):
    def setUp(self) -> None:
        self.validator = StudentValidator()
        self.student_repo = StudentRepo(self.validator, GradeRepo(GradeValidator()))
        self.student = Student("1", "Lol")

    def test_addition(self):
        self.student_repo.add(self.student)
        self.assertEqual(self.student_repo.find_by_id("1"), self.student)

    def test_remove(self):
        self.student_repo.add(self.student)
        self.student_repo.remove(self.student)
        self.assertEqual(self.student_repo.find_by_id("1"), None)

    def test_get_all(self):
        self.student_repo.add(self.student)
        self.assertEqual(self.student_repo.find_all(), [self.student])

    def test_update(self):
        self.student_repo.add(self.student)
        new_student = Student("1", "Mark")
        self.student_repo.update(new_student)
        self.assertEqual(self.student_repo.find_by_id("1"), new_student)