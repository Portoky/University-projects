import unittest

from src.repository.repository_exception import RepositoryException
from src.domain.grade import Grade
from src.domain.grade_validator import GradeValidator
from src.repository.grade_repo import GradeRepo
from src.repository.student_repo import StudentRepo
from src.domain.student_validator import StudentValidator
from src.domain.student import Student


class TestGradeRepo(unittest.TestCase):
    def setUp(self) -> None:
        self.validator = GradeValidator()
        self.grade_repo = GradeRepo(self.validator)
        self.validator2 = StudentValidator()
        self.student_repo = StudentRepo(self.validator2, self.grade_repo)
        self.grade = Grade("1", "1", "1", 10)
        self.student = Student("1", "Michael")

    def test_addition(self):
        self.grade_repo.add(self.grade)
        self.assertEqual(self.grade_repo.find_by_id("1"), self.grade)
        self.student_repo.add(self.student)
        self.assertEqual(self.student_repo.find_by_id("1"), self.student)

    def test_remove(self):
        self.student_repo.add(self.student)
        self.grade_repo.add(self.grade)
        self.student_repo.remove(self.student)
        self.assertEqual(self.grade_repo.find_by_id(self.grade.grade_id), None)

    def test_get_all(self):
        self.grade_repo.add(self.grade)
        self.assertEqual(self.grade_repo.find_all(), [self.grade])

    def test_update(self):
        self.grade_repo.add(self.grade)
        new_grade = Grade("1", "1", "1", 9)
        self.grade_repo.update(new_grade)
        self.assertEqual(self.grade_repo.find_by_id("1"), new_grade)