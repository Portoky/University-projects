import unittest

from src.domain.exceptions import ValidatorException
from src.domain.grade import Grade
from src.domain.grade_validator import GradeValidator


class Test_Grade(unittest.TestCase):
    def test_grade(self):
        grade = Grade("1", "1", "1", 10)
        self.assertEqual(grade.discipline_id, "1")
        self.assertEqual(grade.student_id, "1")
        self.assertEqual(grade.grade_value, 10)
    def test_discipline_validator(self):
        validator = GradeValidator()
        grade = Grade("1", "1", "1", 11)
        self.assertRaises(ValidatorException, validator.validate, grade)