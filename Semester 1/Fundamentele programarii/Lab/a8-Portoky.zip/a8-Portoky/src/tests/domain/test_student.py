import unittest

from src.domain.exceptions import ValidatorException
from src.domain.student import Student
from src.domain.student_validator import StudentValidator


class Test_Student(unittest.TestCase):
    def test_student(self):
        student = Student(1, "Michael")
        self.assertEqual(student.id, 1)
        self.assertEqual(student.name, "Michael")
    def test_student_validator(self):
        validator = StudentValidator()
        student = Student(1, "")
        self.assertRaises(ValidatorException, validator.validate, student)
