import unittest

from src.domain.discipline import Discipline
from src.domain.discipline_validator import DisciplineValidator
from src.domain.exceptions import ValidatorException


class Test_Discipline(unittest.TestCase):
    def test_discipline(self):
        discipline = Discipline(1, "Maths")
        self.assertEqual(discipline.id, 1)
        self.assertEqual(discipline.name, "Maths")
    def test_discipline_validator(self):
        validator = DisciplineValidator()
        discipline = Discipline(1, "")
        self.assertRaises(ValidatorException, validator.validate, discipline)