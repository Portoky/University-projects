import unittest

from src.domain.discipline_validator import DisciplineValidator
from src.domain.grade import Grade
from src.domain.grade_validator import GradeValidator
from src.repository.discipline_repo import DisciplineRepo
from src.repository.grade_repo import GradeRepo
from src.repository.student_repo import StudentRepo
from src.domain.student_validator import StudentValidator
from src.domain.student import Student
from src.domain.discipline import Discipline
from src.services.discipline_service import DisciplineService
from src.services.grade_service import GradeService
from src.services.student_service import StudentService


class TestService(unittest.TestCase):
    def setUp(self) -> None:
        self.student1 = Student("1", "Mark")
        self.discipline1 = Discipline("1", "Maths")
        self.grade1 = Grade("1", "1", "1", 9)

        self.grade_validator = GradeValidator()
        self.grade_repository = GradeRepo(self.grade_validator)

        self.student_validator = StudentValidator()
        self.student_repository = StudentRepo(self.student_validator, self.grade_repository)

        self.discipline_validator = DisciplineValidator()
        self.discipline_repository = DisciplineRepo(self.discipline_validator, self.grade_repository)

        self.grade_service = GradeService(self.grade_repository, self.student_repository, self.discipline_repository)
        self.student_service = StudentService(self.student_repository)
        self.discipline_service = DisciplineService(self.discipline_repository)

    def test_add(self):
        self.discipline_service.add_discipline("1", "Maths")
        self.assertEqual(self.discipline_service.list_disciplines(), [self.discipline1])
        self.student_service.add_student("1", "Mark")
        self.assertEqual(self.student_service.list_students(), [self.student1])
        self.grade_service.add_grade("1", "1", "1", 9)
        self.assertEqual(self.grade_service.list_grades(), [self.grade1])

    def test_remove(self):
        self.discipline_service.add_discipline("1", "Maths")
        self.student_service.add_student("1", "Mark")
        self.grade_service.add_grade("1", "1", "1", 9)
        self.discipline_service.remove_discipline("1")
        self.student_service.remove_student("1")
        self.assertEqual(self.student_service.list_students(), [])
        self.assertEqual(self.discipline_service.list_disciplines(), [])
        self.assertEqual(self.grade_service.list_grades(), [])

    def test_update(self):
        self.discipline_service.add_discipline("1", "Maths")
        self.student_service.add_student("1", "Mark")
        self.discipline_service.update_discipline("1", "Algebra")
        self.student_service.update_student("1", "Emese")
        self.assertEqual(self.student_service.list_students(), [Student("1", "Emese")])
        self.assertEqual(self.discipline_service.list_disciplines(), [Discipline("1", "Algebra")])

    def test_failed_students(self):
        self.discipline_service.add_discipline("1", "Maths")
        self.student_service.add_student("1", "Emese")
        self.grade_service.add_grade("1", "1", "1", 4)
        self.assertEqual(self.grade_service.get_failing_students(), [Student("1", "Emese")])

    def test_best_students(self):
        self.discipline_service.add_discipline("1", "Maths")
        self.student_service.add_student("1", "Emese")
        self.student_service.add_student("2", "Marci")
        self.grade_service.add_grade("1", "1", "1", 10)
        self.grade_service.add_grade("2", "1", "1", 10)
        self.grade_service.add_grade("3", "1", "1", 9)
        self.grade_service.add_grade("4", "1", "2", 9)
        self.grade_service.add_grade("5", "1", "2", 9)
        self.grade_service.add_grade("6", "1", "2", 9)
        self.assertEqual(self.grade_service.get_best_students(), [Student("1", "Emese"), Student("2", "Marci")])

    def test_best_disciplines(self):
        self.discipline_service.add_discipline("1", "Maths")
        self.discipline_service.add_discipline("2", "Biology")
        self.student_service.add_student("1", "Emese")
        self.student_service.add_student("2", "Marci")
        self.grade_service.add_grade("1", "1", "1", 10)
        self.grade_service.add_grade("2", "1", "1", 10)
        self.grade_service.add_grade("3", "1", "1", 9)
        self.grade_service.add_grade("4", "1", "2", 9)
        self.grade_service.add_grade("5", "1", "2", 9)
        self.grade_service.add_grade("6", "2", "2", 9)
        self.grade_service.add_grade("7", "2", "2", 9)
        self.grade_service.add_grade("8", "2", "2", 9)
        self.grade_service.add_grade("9", "2", "2", 9)
        self.assertEqual((self.grade_service.get_best_disciplines()), [Discipline("1", "Maths"), Discipline("2", "Biology")])

