"""
this package file contains the class of the repository for complex numbers
"""
import copy

class ComplexInMemoryRepository:
    def __init__(self, validator):
        self.all_complex_numbers = [] #since we do not need an id it is enough to store it in a list
        self.__validator = validator

    '''CRUD operations: here we just need to save it and display all numbers'''

    def save(self, complex):
        """
        We save the previous list of complex number in the history
        And we append the new element to the complex number
        :param complex:
        :return:
        """
        self.__validator.validate(complex) #first we validate!
        self.all_complex_numbers.append(complex)

    def find_by_index(self, complex_index):
        return self.all_complex_numbers[complex_index]

    def find_all(self):
        """Returns the list of complex number the repo contains"""
        return self.all_complex_numbers[:]

    def delete_by_index(self, complex_index):
        del self.all_complex_numbers[complex_index]

    def update_all(self, new_list_of_complex_numbers):
        self.all_complex_numbers.clear()
        for complex in new_list_of_complex_numbers:
            self.all_complex_numbers.append(complex)


    def __len__(self):
        return len(self.all_complex_numbers)

    def __str__(self):
        res = ""
        for complex in self.all_complex_numbers:
            res += str(complex)
            res += "\n"
        return res


