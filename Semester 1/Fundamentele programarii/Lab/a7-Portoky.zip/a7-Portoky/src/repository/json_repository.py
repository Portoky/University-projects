import json
from src.repository.file_repository import ComplexFileRepository


class ComplexJsonRepository(ComplexFileRepository):

    def _save_file(self, list_of_complex_numbers):
        f = open(self._file_name, "w", encoding='utf-8')
        json.dumps(list_of_complex_numbers, f)
        f.close()

    def _load_file(self):
        fin = open(self._file_name, "r", encoding='utf-8')
        self.all_complex_numbers = json.load(fin)
        fin.close()
