
import pickle
from src.repository.file_repository import ComplexFileRepository
from src.domain.entities import Complex

class ComplexBinRepository(ComplexFileRepository):

    def _save_file(self, list_of_complex_numbers):
        fout = open(self._file_name, "wb")
        pickle.dump(list_of_complex_numbers, fout)
        fout.close()

    def _load_file(self):
        fin = open(self._file_name, "rb")
        self.all_complex_numbers = pickle.load(fin)
        fin.close()

