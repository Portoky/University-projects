
from src.repository.complex_repository import ComplexInMemoryRepository
from src.domain.entities import Complex

class ComplexFileRepository(ComplexInMemoryRepository):
    def __init__(self, file_name, validator):
        super().__init__(validator)
        self._file_name = file_name
        self._load_file()

    def save(self, complex):
        super().save(complex)
        new_list_of_complex_numbers = self.all_complex_numbers[:]
        self._save_file(new_list_of_complex_numbers)

    def delete_by_index(self, complex_index):
        super().delete_by_index(complex_index)
        self._save_file()

    def update_all(self, new_list_of_complex_numbers):
        super().update_all(new_list_of_complex_numbers)
        #new_list_of_complex_numbers = self.all_complex_numbers[:]
        self._save_file(new_list_of_complex_numbers)

    def _save_file(self, list_of_complex_numbers):
        with open(self._file_name, "w") as f:
            for complex in list_of_complex_numbers:
                f.write(f",{str(complex)}")

    def _load_file(self):
        with open(self._file_name, "r") as f:
            for line in f:
                complexes = line.strip().split(",")
                for complex in complexes:
                    if len(complex) != 0:
                        pos1 = complex.find(" +")
                        pos2 = complex.find(" -")

                        if pos1 == -1: #so we have a - sign
                            real = int(complex[:pos2])
                            imaginary = int(complex[pos2:len(complex)-1]) #so the letter i is not in it
                        elif pos2 == -1: #so we have a + sign
                            real = int(complex[:pos1])
                            imaginary = int(complex[pos1:len(complex)-1])
                        element = Complex(real, imaginary)
                        super().save(element)

