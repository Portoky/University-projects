

from src.domain.entities import Complex
from src.repository.complex_repository import ComplexInMemoryRepository
from src.domain.validators import ComplexValidator

class ComplexService:
    def __init__(self, complex_repository):
        self.__complex_repository = complex_repository
        self.__history = []  # contains a list of previous list of complex numbers

    def add_complex(self, real_part, imaginary_part):
        """
        Creates a real number and appends saves to the repo
        :param real_part:
        :param imaginary_part:
        :return:
        """
        complex = Complex(real_part, imaginary_part)
        self.__history.append(self.__complex_repository.find_all())
        self.__complex_repository.save(complex)

    def get_all(self):
        return self.__complex_repository.find_all()

    def filter_between_indexes(self, start, end):
        '''
        Creates a new list of numbers which contains the elements from the list between the indexes
        and updates the repo with it
        :param start:
        :param end:
        '''
        start = int(start)
        end = int(end)
        new_list_of_complex_numbers = []

        if start > len(self.__complex_repository.find_all()) or end > len(self.__complex_repository.find_all()) or start > end:
            raise ValueError("Interval not corresponding")
            return

        self.__history.append(self.__complex_repository.find_all())#saving previous repo
        for i in range(start, end+1):
            new_list_of_complex_numbers.append(self.__complex_repository.find_by_index(i)) #creating a new list of complex nmbers with elements within the indexes

        self.__complex_repository.update_all(new_list_of_complex_numbers) #updating the repo with new list

    def undo(self):
        if len(self.__history) == 0:
            raise ValueError("Nothing to undo")
        previous_list_of_complex_numbers = self.__history[-1][:]
        self.__complex_repository.update_all(previous_list_of_complex_numbers)
        self.__history.pop(-1)


