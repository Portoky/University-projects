
from src.services.complex_service import ComplexService
from src.domain.entities import Complex
from src.repository.complex_repository import ComplexInMemoryRepository
from src.repository.binary_repository import ComplexBinRepository
from src.domain.validators import ComplexValidator
import random


class Console:
    def __init__(self, complex_service):
        self.__complex_service = complex_service
        self.commands = {"+": self.__add_complex_number, "d": self.__display, "f": self.__filter, "u": self.__undo}
        self.generate_items()

    def run_console(self):
        while True:
            self.__print_input()
            command = input(">").strip().lower()
            if command == "x":
                break
            if command not in self.commands.keys():
                print("Option not implemented yet!")
            else:
                try:
                    self.commands[command]()
                except ValueError as ve:
                    print("Error: " + str(ve))

    def __print_input(self):
        print("Choose from one of the followings:")
        print("+ :add a complex numbers to the list")
        print("d :display all complex numbers")
        print("u :undo last operation")
        print("f :filter between indexes")
        print("x :exit the application")

    def __add_complex_number(self):
        real = input("Real part of complex number: ")
        imaginary = input("Imaginary part of complex number: ")
        self.__complex_service.add_complex(real, imaginary)

    def __display(self):
        for complex in self.__complex_service.get_all():
            print(complex)

    def __filter(self):
        start = input("Add starting index: ")
        end = input("Add ending index: ")
        self.__complex_service.filter_between_indexes(start, end)

    def __undo(self):
        self.__complex_service.undo()

    def generate_items(self):
        for i in range(0, 10):
            real = random.randint(-100, 100)
            imaginary = random.randint(-100, 100)
            self.__complex_service.add_complex(real, imaginary)


