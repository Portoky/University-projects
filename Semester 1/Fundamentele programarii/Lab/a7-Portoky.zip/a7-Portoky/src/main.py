from src.services.complex_service import ComplexService
from src.domain.validators import ComplexValidator
from src.repository.complex_repository import ComplexInMemoryRepository
from src.repository.file_repository import ComplexFileRepository
from src.repository.binary_repository import ComplexBinRepository
from src.repository.json_repository import ComplexJsonRepository
from src.ui.console import Console
import pickle
import json

if __name__ == '__main__':
    validator = ComplexValidator()
    repo = ComplexFileRepository("../test.txt", validator)
    #repo = ComplexInMemoryRepository(validator)
    #repo = ComplexBinRepository("repo.bin", validator)
    #repo = ComplexJsonRepository("../repo.json", validator)
    Service = ComplexService(repo)
    console = Console(Service)
    console.run_console()