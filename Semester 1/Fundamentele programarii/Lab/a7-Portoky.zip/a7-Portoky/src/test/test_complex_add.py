import unittest
from src.repository.complex_repository import ComplexInMemoryRepository
from src.domain.entities import Complex
from src.domain.validators import ComplexValidator
class TestComplex(unittest.TestCase):
    def runTest(self):
        self.z1 = Complex(5, -6)
        self.z2 = Complex(7, 8)
        self.validator = ComplexValidator()
        self.repo = ComplexInMemoryRepository(self.validator)
        self.assertEqual(self.z1.real, 5, "Real part should be 5")
        self.assertEqual(self.z1.imaginary, -6, "Im part should be -6")

        self.repo.save(self.z1)
        self.assertEqual(self.repo.all_complex_numbers[-1], self.z1, "Save method not working")

if __name__ == '__main__':
    unittest.main()