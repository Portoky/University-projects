"""
this package file contains the class representing a complex number
"""


class Complex:
    def __init__(self, real, imaginary):
        real = int(real)
        imaginary = int(imaginary)
        self.__real = real
        self.__imaginary = imaginary


    @property
    def imaginary(self):
        return self.__imaginary
    @property
    def real(self):
        return self.__real

    def __str__(self):
        if self.__imaginary < 0:
            return f"{self.real} {self.imaginary}i"
        else:
            return f"{self.real} +{self.imaginary}i"
