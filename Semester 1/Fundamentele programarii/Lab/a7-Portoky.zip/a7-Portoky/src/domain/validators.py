

class ComplexValidator:
    def validate(self, complex):
        if complex.real != int(complex.real) or complex.imaginary != int(complex.imaginary):
            raise ValueError("Real and imaginary part should be an integer")