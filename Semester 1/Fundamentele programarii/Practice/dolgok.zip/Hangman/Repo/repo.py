from Domain.entity import Sentence


class RepoException(Exception):
    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message


class SentenceRepo:
    def __init__(self, validator):
        self.__repo = {}
        self.__validator = validator

    def find_all(self):
        '''Returns a list of the sentences'''
        return list(self.__repo.values())

    def find_by_sentence(self, sentence: str):
        '''We use the sentence as an id'''
        if sentence not in self.__repo:
            return None
        return self.__repo[sentence]

    def add(self, sentence: Sentence):
        """we first validate check if it is not duplicate then put it into the repository the sentence"""
        self.__validator.validate(sentence)
        if sentence.sentence in self.__repo:
            raise RepoException("Sentence already in repo")
        self.__repo[sentence.sentence] = sentence


class SentenceFileRepo(SentenceRepo):
    def __init__(self, file_name, validator):
        super().__init__(validator)
        self.__file_name = file_name
        self.load_file()

    def load_file(self):
        try:
            fin = open(self.__file_name, "rt")
            lines = fin.readlines()
            fin.close()
        except FileNotFoundError:
            raise RepoException("FileNotFound!")
        except IOError:
            raise RepoException("IOError.")

        for line in lines:
            sentence_obj = Sentence(line[:-1])# so the \n is not in it
            super().add(sentence_obj)

    def save_file(self):
        try:
            fout = open(self.__file_name, "wt")
            for sentence_obj in self.find_all():
                line = sentence_obj.sentence + "\n"
                fout.write(line)
        except FileNotFoundError:
            raise RepoException("FileNotFOund!")
        except IOError:
            raise RepoException("IOError.")
        fout.close()

    def add(self, sentence):
        super().add(sentence)
        self.save_file()
