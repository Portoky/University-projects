from Domain.entity import ValidatorException
from Repo.repo import RepoException
from Service.controller import GameException


class UI:
    def __init__(self, controller):
        self._controller = controller
        self.command = {"1": self.add_sentence, "2": self.start_game}
        self.game_over = False

    def print_options(self):
        print("1.Add sentence")
        print("2.Start the game")

    def start_ui(self):
        while not self.game_over:
            try:
                self.print_options()
                cmd = input(">")
                self.command[cmd]()
            except GameException as ge:
                print(ge)
                self.game_over = True
            except RepoException as re:
                print(re)
            except ValidatorException as ve:
                print(ve)
            except KeyError:
                print("Option not implemented yet.")

    def add_sentence(self):
        sentence = input("The sentence you want to add: ")
        self._controller.add(sentence)

    def start_game(self):
        sentence_obj = self._controller.choose_sentence()
        print("Output: " + str(sentence_obj))

        while True:
            try:
                guess_letter = input("Your guess: ")
                self._controller.letter_add(sentence_obj, guess_letter)
            except GameException as ge:
                print(ge)
            else:
                print("Output changes to: " + str(sentence_obj) + " - " + self._controller.get_hangman())
                win = self._controller.win_or_lose(sentence_obj)
                if win is not None:
                    if win:
                        raise GameException("You won")
                    if not win:
                        raise GameException("You Lost")