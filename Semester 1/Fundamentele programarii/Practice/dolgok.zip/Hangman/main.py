from Domain.entity import SentenceValidator
from Repo.repo import *
from Service.controller import *
from Ui.ui import *

if __name__ == "__main__":
    repo = SentenceFileRepo("sentence.txt", SentenceValidator())
    controller = Controller(repo)
    ui = UI(controller)
    ui.start_ui()