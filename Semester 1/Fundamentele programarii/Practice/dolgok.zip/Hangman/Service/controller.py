import random

from Domain.entity import Sentence


class GameException(Exception):
    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message

class Controller:
    def __init__(self, repo):
        self.__repo = repo
        self.__index = 0 #for the hangman
        self.__hangman = "hangman"

    def add(self, sentence: str):
        '''we create a sentence object then add it to the repo'''
        sentence_obj = Sentence(sentence)
        self.__repo.add(sentence_obj)

    def choose_sentence(self):
        '''Choose a random sentence object from the repo'''
        return random.choice(self.__repo.find_all())

    def win_or_lose(self, sentence_obj):
        '''We check if we won or lost. Returns True if the player won, False if lost, None otherwise'''
        if self.__index == len(self.__hangman):
            return False
        win = True
        for letter in sentence_obj.sentence:
            if letter not in sentence_obj.known_letters and letter != " ":
                win = False
                break
        if win:
            return True
        return None

    def letter_add(self, sentence_obj, letter: str):
        '''if letter is not in the sentence we increase the index -> more is written out of the word hangman
            else, we add the letter to the known letters
            GameException raised if it the parameter letter is not a character
        '''
        if len(letter) > 2:
            raise GameException("not a character!")
        if letter not in sentence_obj.sentence:
            self.__index += 1
        else:
            sentence_obj.known_letters.add(letter)

    def get_hangman(self):
        return self.__hangman[:self.__index]