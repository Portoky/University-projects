class Sentence:
    def __init__(self, sentence: str):
        self.__sentence = sentence
        self.__known_letters = set()  # Letter in the set -> known

        self.__known_letters.add(sentence[0])
        self.__known_letters.add(sentence[-1])

        for i in range(1, len(sentence) - 1):
            if sentence[i] == ' ':
                self.__known_letters.add(sentence[i - 1])
                self.__known_letters.add(sentence[i + 1])

    @property
    def sentence(self):
        return self.__sentence

    @property
    def known_letters(self):
        return self.__known_letters

    @known_letters.setter
    def known_letters(self, value):
        self.__known_letters.add(value)

    def __str__(self):
        line = ""
        for letter in self.sentence:
            if letter in self.__known_letters or letter == " ":
                line += letter
            else:
                line += "_"
        return line


class SentenceValidator:
    @staticmethod
    def validate(sentence):
        if not isinstance(sentence, Sentence) or len(sentence.sentence) < 3:
            return ValidatorException("Invalid sentence")


class ValidatorException(Exception):
    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message
