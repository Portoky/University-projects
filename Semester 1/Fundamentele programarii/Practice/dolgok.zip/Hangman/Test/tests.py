import unittest

from Domain.entity import SentenceValidator, Sentence
from Repo.repo import SentenceFileRepo, RepoException
from Service.controller import Controller


class TestFunctions(unittest.TestCase):
    def setUp(self) -> None:
        self.repo = SentenceFileRepo("sentence.txt", SentenceValidator())
        self.controller = Controller(self.repo)
        self.s1 = Sentence("Kaka maka")

    def test_repo(self):
        self.repo.add(self.s1)
        self.assertEqual(self.repo.find_all(), [self.s1])
        self.assertRaises(RepoException, self.repo.add, self.s1)

    def test_controller(self):
        self.repo.add(self.s1)
        obj = self.controller.choose_sentence()
        l = {"K", "a", "m"}
        self.assertEqual(obj.known_letters, l)