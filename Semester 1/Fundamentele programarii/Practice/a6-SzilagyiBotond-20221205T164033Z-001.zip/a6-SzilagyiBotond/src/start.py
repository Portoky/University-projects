#
# This module is used to invoke the program's UI and start it. It should not contain a lot of code.
#
from functions import *
from ui import run_console
if __name__ == "__main__":
    test_add()
    test_delete_by_category()
    test_delete_by_day()
    run_console()
