#
# This is the program's UI module. The user interface and all interaction with the user (print and input statements) are found here
#
from functions import *


def read_command():
    input_command = input(">")
    blank_position = input_command.find(" ")
    if blank_position == -1:
        return input_command, []
    command_to_do = input_command[:blank_position]
    arguments_of_the_command = input_command[blank_position + 1:]
    arguments_of_the_command = arguments_of_the_command.split()
    arguments_of_the_command = [argument.strip() for argument in arguments_of_the_command]
    return command_to_do, arguments_of_the_command


def insert_new_expense(history_of_modifications, monthly_expenses, category_types, day, amount, type):
    try:
        amount = int(amount)
        type = str(type)
        day = int(day)
        if type not in category_types:
            raise ValueError("Invalid category type")
        if amount <= 0:
            raise ValueError("The amount should be bigger than 0")
        if 0 >= day or day > 31:
            raise ValueError("Invalid day input")
        add_expense(monthly_expenses, day, amount, type)
        history_of_modifications.append(monthly_expenses[:])
        return monthly_expenses
    except ValueError as ve:
        print(ve)
        return monthly_expenses


def remove_period(history_of_modifications, monthly_expenses, category_types, start_day, to, end_day):
    """This function removes all expenses between the given days.

    :param history_of_modifications:
    :param monthly_expenses:
    :param category_types:
    :param start_day:
    :param to:
    :param end_day:
    :return:
    """
    try:
        start_day = int(start_day)
        end_day = int(end_day)
        to = str(to)
        if to != "to":
            raise ValueError("Wrong syntax")
        if end_day <= start_day:
            raise ValueError("Start_day or end_day has wrong input data")
        if 0 >= start_day or start_day > 31 or end_day <= 0 or end_day > 31:
            raise ValueError("Start_day or end_day has wrong input data")
        for i in range(start_day, end_day + 1):
            monthly_expenses = remove_expense_from_day(monthly_expenses, category_types, i)
        history_of_modifications.append(monthly_expenses[:])
        return monthly_expenses
    except ValueError as ve:
        print(ve)
        return monthly_expenses


def list_expenses_from_category_with_specific_expense(history_of_modifications, monthly_expenses, category_types, type, operand, amount):
    """This function prints out expenses from a category with a given attribute(greater than something, smaller than something, equal to something)

    :param history_of_modifications:
    :param monthly_expenses:
    :param category_types:
    :param type:
    :param operand:
    :param amount:
    :return:
    """
    try:
        amount = int(amount)
        if type not in category_types:
            raise ValueError("Invalid category type")
        if operand not in ["=", ">", "<"]:
            raise ValueError("Wrong operand type")
        if amount <= 0:
            raise ValueError("The amount should be bigger than 0")
        if operand == "=":
            for i in range(len(monthly_expenses)):
                if monthly_expenses[i]['type'] == type and monthly_expenses[i]['amount'] == amount:
                    print(monthly_expenses[i])
        if operand == ">":
            for i in range(len(monthly_expenses)):
                if monthly_expenses[i]['type'] == type and monthly_expenses[i]['amount'] > amount:
                    print(monthly_expenses[i])
        if operand == "<":
            for i in range(len(monthly_expenses)):
                if monthly_expenses[i]['type'] == type and monthly_expenses[i]['amount'] < amount:
                    print(monthly_expenses[i])
        return monthly_expenses
    except ValueError as ve:
        print(ve)
        return monthly_expenses


def add_new_expense_to_current_day(history_of_modifications, monthly_expenses, category_types, amount, type):
    try:
        amount = int(amount)
        type = str(type)
        current_day = int(get_current_day())
        if type not in category_types:
            raise ValueError("Invalid category type")
        if amount <= 0:
            raise ValueError("The amount should be bigger than 0")
        add_expense(monthly_expenses, current_day, amount, type)
        history_of_modifications.append(monthly_expenses[:])
    except ValueError as ve:
        print(ve)


def remove_expense_from_day_or_category(history_of_modifications, monthly_expenses, category_types, day_or_category):
    """This function removes expenses from a day or category, determined by the nature of the input

    :param history_of_modifications:
    :param monthly_expenses:
    :param category_types:
    :param day_or_category:
    :return:
    """
    try:
        day_or_category = int(day_or_category)
        monthly_expenses = remove_expense_from_day(history_of_modifications, monthly_expenses, category_types, day_or_category)
        return monthly_expenses

    except ValueError:
        day_or_category = str(day_or_category)
        monthly_expenses = remove_expense_from_category(history_of_modifications, monthly_expenses, category_types, day_or_category)
        return monthly_expenses


def remove_expense_from_day(history_of_modifications, monthly_expenses, category_types, day_to_delete):
    try:
        if 0 >= day_to_delete or day_to_delete > 31:
            raise ValueError("Invalid day input")
        monthly_expenses = delete_expense_by_day(monthly_expenses, day_to_delete)
        history_of_modifications.append(monthly_expenses[:])
        return monthly_expenses
    except ValueError as ve:
        print(ve)
        return monthly_expenses


def remove_expense_from_category(history_of_modifications, monthly_expenses, category_types, type_to_delete):
    try:
        if type_to_delete not in category_types:
            raise ValueError("Invalid category type")
        monthly_expenses = delete_expense_by_type(monthly_expenses, type_to_delete)
        history_of_modifications.append(monthly_expenses[:])
        return monthly_expenses
    except ValueError as ve:
        print(ve)
        return monthly_expenses


def filter_by_category(history_of_modifications, monthly_expenses, category_types, type):
    try:
        if type not in category_types:
            raise ValueError("Invalid category type")
        monthly_expenses = keep_by_type(monthly_expenses, type)
        history_of_modifications.append(monthly_expenses[:])
        return monthly_expenses
    except ValueError as ve:
        print(ve)
        return monthly_expenses


def list_expenses_from_category(history_of_modifications, monthly_expenses, category_types, type):
    try:
        if type not in category_types:
            raise ValueError("Invalid category type")
        for i in range(len(monthly_expenses)):
            if monthly_expenses[i]['type'] == type:
                print(monthly_expenses[i])
        return monthly_expenses
    except ValueError as ve:
        print(ve)
        return monthly_expenses


def filter_by_category_and_amount(history_of_modifications, monthly_expenses, category_types, type, operand, amount):
    try:
        amount = int(amount)
        if type not in category_types:
            raise ValueError("Invalid category type")
        monthly_expenses = keep_by_type(monthly_expenses, type)
        if operand not in ["=", ">", "<"]:
            raise ValueError("Wrong operand type")
        if amount <= 0:
            raise ValueError("The amount should be bigger than 0")
        if operand == "=":
            monthly_expenses = keep_equal(monthly_expenses, amount)
        if operand == ">":
            monthly_expenses = keep_greater_than(monthly_expenses, amount)
        if operand == "<":
            monthly_expenses = keep_less_than(monthly_expenses, type)
        history_of_modifications.append(monthly_expenses[:])
        return monthly_expenses
    except ValueError as ve:
        print(ve)
        return monthly_expenses


def list_all_expenses(monthly_expenses):
    print(*monthly_expenses, sep="\n")


def print_commands(monthly_expenses):
    print("add <sum> <category> -> add to the current day an expense")
    print("insert <day> <sum> <category> -> insert to day an expense")
    print("remove <day> -> remove all expenses for a day")
    print("remove <start day> to <end day> ->  remove all expenses between two days")
    print("remove <category> -> remove all expenses for a category")
    print("list -> display all expenses")
    print("list <category> -> display all the expenses for a category")
    print("list <category> [ < | = | > ] <value> -> display all expenses for a category with a condition")
    print("filter <category> -> keep only expenses in a category")
    print("filter <category> [ < | = | > ] <value> -> keep only expenses in a category with a condition")
    print("undo -> undo the last adding or removal operations effect")
    print("help -> list of commands")
    print("exit -> exit the program")


def run_console():
    print("Print 'help' for commands")
    monthly_expenses=[]
    monthly_expenses = create_10_entry_elements(monthly_expenses)
    history_of_modifications=[monthly_expenses]
    commands_with_3_argument = {"insert": insert_new_expense, "remove": remove_period,
                                "list": list_expenses_from_category_with_specific_expense,
                                "filter": filter_by_category_and_amount}
    commands_with_2_argument = {"add": add_new_expense_to_current_day}
    commands_with_1_argument = {"remove": remove_expense_from_day_or_category, "list": list_expenses_from_category,
                                "filter": filter_by_category}
    commands_with_0_argument = {"list": list_all_expenses, "help": print_commands}
    category_types = ["housekeeping", "food", "transport", "clothing", "internet", "others"]
    while True:
        command, arguments = read_command()
        if command == "exit":
            print("Thanks for using the application :)")
            break
        if len(arguments) == 0:
            if command == "undo":
                if len(history_of_modifications) == 1:
                    print("There is nothing to undo")
                else:
                    history_of_modifications.pop(-1)
                    monthly_expenses = history_of_modifications[-1]
                    print("Undo succesful")
            else:
                try:
                    commands_with_0_argument[command](monthly_expenses)
                except KeyError:
                    print("This option is not yet implemented :) ")
                except TypeError:
                    print("Invalid use of the option, type help for options :)")
        elif len(arguments) == 1:
            try:
                monthly_expenses = commands_with_1_argument[command](history_of_modifications,monthly_expenses, category_types, *arguments)
            except KeyError:
                print("This option is not yet implemented :) ")
            except TypeError:
                print("Invalid use of the option, type help for options :)")
        elif len(arguments) == 2:
            try:
                commands_with_2_argument[command](history_of_modifications,monthly_expenses, category_types, *arguments)
            except KeyError:
                print("This option is not yet implemented :) ")
            except TypeError:
                print("Invalid use of the option, type help for options :)")
        elif len(arguments) == 3:
            try:
                monthly_expenses = commands_with_3_argument[command](history_of_modifications,monthly_expenses, category_types, *arguments)
            except KeyError:
                print("This option is not yet implemented :) ")
            except TypeError:
                print("Invalid use of the option, type help for options :)")
