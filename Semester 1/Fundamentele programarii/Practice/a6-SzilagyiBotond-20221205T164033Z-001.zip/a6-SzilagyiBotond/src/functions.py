#
# The program's functions are implemented here. There is no user interaction in this file, therefore no input/print statements. Functions here
# communicate via function parameters, the return statement and raising of exceptions.
#
import datetime


def get_current_day():
    current_time = datetime.datetime.now()
    return current_time.day


def get_day(expense):
    return expense["day"]


def set_day(expense):
    expense["day"] = new_day


def get_amount(expense):
    return expense["amount"]


def set_amount(expense):
    expense["amount"] = new_amount


def get_type(expense):
    return expense["type"]


def set_type(expense):
    expense["type"] = new_type


def create_expense(day, amount, type):
    return {"day": day, "amount": amount, "type": type}


def add_expense(monthly_expenses, day, amount, type):
    new_expense = create_expense(day, amount, type)
    monthly_expenses.append(new_expense)


def create_10_entry_elements(monthly_expenses):
    add_expense(monthly_expenses, 10, 11, "food")
    add_expense(monthly_expenses, 11, 12, "transport")
    add_expense(monthly_expenses, 12, 13, "others")
    add_expense(monthly_expenses, 13, 14, "housekeeping")
    add_expense(monthly_expenses, 14, 15, "clothing")
    add_expense(monthly_expenses, 15, 16, "internet")
    add_expense(monthly_expenses, 16, 17, "food")
    add_expense(monthly_expenses, 17, 18, "transport")
    add_expense(monthly_expenses, 18, 19, "others")
    add_expense(monthly_expenses, 19, 20, "housekeeping")
    return monthly_expenses


def delete_expense_by_day(monthly_expenses, day):
    result = list(filter(lambda expense: expense['day'] != day, monthly_expenses))
    return result


def delete_expense_by_type(monthly_expenses, type):
    result = list(filter(lambda expense: expense['type'] != type, monthly_expenses))
    return result


def keep_by_type(monthly_expenses, type):
    result = list(filter(lambda expense: expense['type'] == type, monthly_expenses))
    return result


def keep_equal(monthly_expenses, amount):
    result = list(filter(lambda expense: expense['amount'] == amount, monthly_expenses))
    return result


def keep_greater_than(monthly_expenses, amount):
    result = list(filter(lambda expense: expense['amount'] > amount, monthly_expenses))
    return result


def keep_less_than(monthly_expenses, amount):
    result = list(filter(lambda expense: expense['amount'] < amount, monthly_expenses))
    return result


def test_add():
    monthly_expenses = []
    add_expense(monthly_expenses, 10, 10, "food")
    assert monthly_expenses[0]['day'] == 10 and monthly_expenses[0]['amount'] == 10 and monthly_expenses[0][
        'type'] == "food", "Should be {10,10,food}"


def test_delete_by_day():
    monthly_expenses = []
    add_expense(monthly_expenses, 10, 10, "food")
    add_expense(monthly_expenses, 11, 10, "transport")
    day_to_delete = 10
    monthly_expenses = delete_expense_by_day(monthly_expenses, day_to_delete)
    assert monthly_expenses[0]['type'] == "transport", "Delete not working"


def test_delete_by_category():
    monthly_expenses = []
    add_expense(monthly_expenses, 10, 10, "food")
    add_expense(monthly_expenses, 10, 10, "transport")
    type_to_delete = "food"
    monthly_expenses = delete_expense_by_type(monthly_expenses, type_to_delete)
    assert monthly_expenses[0]['type'] == "transport", "Delete not working"
